import styled from "styled-components"

//Cadastro
export const BodyCadastro = styled.div`
    display: flex;
    justify-content: center;
    padding-top: 90px;

`
export const FormInput = styled.div`

    input {
        width: 580px;
    }

    select {
        width: 580px;
    }
`
